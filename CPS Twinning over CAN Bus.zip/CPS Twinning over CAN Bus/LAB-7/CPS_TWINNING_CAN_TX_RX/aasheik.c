#include "aasheik.h"

volatile unsigned long millisCount = 0;

//__attribute__((__constructor__)) void initSysTick(void);

void initSysTick(void)
{
    SysTickIntRegister(SysTick_Handler);
    NVIC_ST_CTRL_R = 0;
    NVIC_ST_RELOAD_R = 16000 - 1;
    NVIC_ST_CURRENT_R = 0;
    NVIC_ST_CTRL_R = 7;

}

void SysTick_Handler(void)
{
    millisCount++;
    segment7();
    keypadRowSelect();
    cancan();
}

int millis(void)
{
    return millisCount;
}

void initTimer0(void)
{

    SYSCTL_RCGCTIMER_R |= (1 << 0);  // Enable Timer0 clock
    while ((SYSCTL_PRTIMER_R & (1 << 0)) == 0)
        ;  // Wait for Timer0 to be ready

    TIMER0_CTL_R &= ~(1 << 0);  // Disable Timer0A before configuration
    TIMER0_CFG_R = 0x00;
    TIMER0_TAMR_R = 0x02;  // Set Timer A as periodic mode
    TIMER0_TAILR_R = (16000000 - 1);
    //TIMER0_IMR_R |= (1 << 0);  // Enable timeout interrupt for Timer0A

    //NVIC_EN0_R |= (1 << 19);  // ✅ Enable Timer0A interrupt in NVIC

    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntRegister(TIMER0_BASE, TIMER_A, TIMER0A_Handler);

    TIMER0_CTL_R |= (1 << 0);  // Enable Timer0A
}

void initUART0Interrupt(int BAUD)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(
            UART0_BASE, SysCtlClockGet(), BAUD,
            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    UARTFIFOLevelSet(UART0_BASE, UART_FIFO_TX1_8, UART_FIFO_RX1_8); // Set RX interrupt at 1/8 full (1 char)
    //UARTFIFODisable(UART0_BASE);  // Enable FIFO (Default)

    UARTIntRegister(UART0_BASE, UART0_Handler_Interrupt); // Register UART0_Handler as the ISR
    UARTIntEnable(UART0_BASE, UART_INT_RX);  // Enable RX interrupt
    IntEnable(INT_UART0);  // Enables UART0 interrupt (macro expands to 5)

    NVIC_EN0_R |= (1 << 5);  // Enable UART0 Interrupt
    IntMasterEnable();  // Enable global interrupts

    UARTEnable(UART0_BASE);

}

void initPORTA(void)
{
    SYSCTL_RCGCGPIO_R |= 0b000001;  // Enable clock for Port A
    while ((SYSCTL_PRGPIO_R & 0b000001) == 0)
        //peripheral-ready-register
        ;

    GPIO_PORTA_DIR_R = 0b11110000;  // PA 6-4 as outputs
    GPIO_PORTA_DEN_R = 0b11110000;   // Enable digital function for PC4, PC5

}

void initPORTB(void)
{
    SYSCTL_RCGCGPIO_R |= 0b000010;  // Enable clock for Port B
    while ((SYSCTL_PRGPIO_R & 0b000010) == 0)
        ;

    GPIO_PORTB_DIR_R = 0b11111111;  // Set all PB pins as outputs
    GPIO_PORTB_DEN_R = 0b11111111;  // Enable digital function for PB pins

}

void initPORTC(void)
{
    SYSCTL_RCGCGPIO_R |= 0b000100;  // Enable clock for Port C
    while ((SYSCTL_PRGPIO_R & 0b000100) == 0)
        ;

    GPIO_PORTC_DIR_R = ~0b11110000;  // PC4, PC5 as inputs
    GPIO_PORTC_DEN_R = 0b11110000;   // Enable digital function for PC4, PC5
    GPIO_PORTC_PUR_R = 0b11110000;

}

void initPORTE(void)
{
    SYSCTL_RCGCGPIO_R |= 0b010000;  // Enable clock for Port E
    while ((SYSCTL_PRGPIO_R & 0b010000) == 0)
        ;  // Wait until Port E is ready

    GPIO_PORTE_DIR_R = 0b00000111;   // PE0 as output
    GPIO_PORTE_DEN_R = 0b00000111;   // Enable digital function for PE0

    GPIO_PORTE_ODR_R |= 0b111;       // Enable open-drain mode for PE3-PE0

}

void initPORTF(void)
{

    SYSCTL_RCGCGPIO_R |= 0b100000;
    while ((SYSCTL_PRGPIO_R & 0b100000) == 0)
    {
    };

    // **Unlock PF0 (SW2)**
    GPIO_PORTF_LOCK_R = 0x4C4F434B;  // Unlock GPIO Port F
    GPIO_PORTF_CR_R |= (1 << 0);  // Allow changes to PF0

    GPIO_PORTF_DIR_R = 0b01110;
    GPIO_PORTF_DEN_R = 0b11111;
    GPIO_PORTF_PUR_R = 0b10001;

}

void initSW(void)
{
    GPIO_PORTF_IS_R |= ((1 << 4) | (1 << 0));        // PF4 is level-sensitive
    //GPIO_PORTF_IBE_R |= ((1<<4)|(1<0));    //     PF4 is not both level
    GPIO_PORTF_IEV_R &= ~((1 << 4) | (1 << 0));    //     PF4 low level event

    GPIO_PORTF_IM_R |= ((1 << 4) | (1 << 0));      // (f) arm interrupt on PF4
    NVIC_EN0_R |= (1 << 30);     // (h) enable interrupt 30 in NVIC

    // Register separate interrupt handlers
    GPIOIntRegister(GPIO_PORTF_BASE, SW_Handler);

    // Enable interrupts for SW1 and SW2
    GPIOIntEnable(GPIO_PORTF_BASE, GPIO_PIN_4 | GPIO_PIN_0);

    GPIO_PORTF_ICR_R = ((1 << 4) | (1 << 0));      // (e) clear flag4

}

void initINTPRI(void)
{

    IntMasterEnable();
    // Enable global interrupts

    // **Set UART0 (IRQ #6) Priority to 0 (Highest)**
    NVIC_PRI1_R = (NVIC_PRI1_R & ~(0b111 << 13)) | (UART0_PRIORITY << 13);

    // **Set SysTick Priority to 1**
    NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R & ~(0b111 << 29))
            | (SYSTICK_PRIORITY << 29);

    /// **Set GPIO Port F (IRQ #30) Priority to 2**
    NVIC_PRI7_R = (NVIC_PRI7_R & ~(0b111 << 21)) | (GPIOF_PRIORITY << 21);

    // **Set Timer0A (IRQ #19) Priority to 3**
    NVIC_PRI4_R = (NVIC_PRI4_R & ~(0b111 << 29)) | (TIMER0A_PRIORITY << 29);
}

// Initialize ADC on PE3 (AIN0)
void initADC0(void)
{
    SYSCTL_RCGCADC_R |= 1;        // Enable ADC0 clock
    SYSCTL_RCGCGPIO_R |= 0x10;    // Enable clock for Port E
    GPIO_PORTE_AFSEL_R |= 0x08;   // Enable alternate function on PE3
    GPIO_PORTE_DEN_R &= ~0x08;    // Disable digital function on PE3
    GPIO_PORTE_AMSEL_R |= 0x08;   // Enable analog function on PE3

    ADC0_ACTSS_R &= ~0x08;        // Disable SS3 for configuration
    ADC0_EMUX_R &= ~0xF000;       // Software trigger
    ADC0_SSMUX3_R = 0;            // Select AIN0 (PE3)
    ADC0_SSCTL3_R = 0x06;         // Enable interrupt and end of conversion
    ADC0_ACTSS_R |= 0x08;         // Enable SS3
}

// Initialize PWM1 on PF2 (M1PWM6)
void initPWM_PF2(uint16_t freq)
{
    SYSCTL_RCGCPWM_R |= 2;        // Enable PWM1 module
    SYSCTL_RCGCGPIO_R |= 0x20;    // Enable clock for Port F
    while ((SYSCTL_PRGPIO_R & 0x20) == 0)
        ;  // Wait for Port F to be ready

    GPIO_PORTF_AMSEL_R &= ~0x04;  // 🔹 Disable analog on PF2
    GPIO_PORTF_AFSEL_R |= 0x04;   // 🔹 Enable alternate function on PF2
    GPIO_PORTF_PCTL_R &= ~0x00000F00;
    GPIO_PORTF_PCTL_R |= 0x00000500; // 🔹 Set PF2 as M1PWM6
    GPIO_PORTF_DEN_R |= 0x04;     // 🔹 Enable digital function on PF2

    SYSCTL_RCC_R &= ~(1 << 20); // 🔹 Use system clock for PWM (No pre-divide)

    PWM1_3_CTL_R = 0;             // 🔹 Disable PWM generator before config
    PWM1_3_GENA_R = 0x0000008C;   // 🔹 Drive high at LOAD, clear at CMPA
    PWM1_3_LOAD_R = 16000000 / freq;   // 🔹 Set period
    PWM1_3_CMPA_R = 1600 - 1;            // 🔹 Default 0% duty cycle
    PWM1_3_CTL_R |= 1;            // 🔹 Enable PWM generator
    PWM1_ENABLE_R |= 0x40;        // 🔹 Enable PWM6 (PF2)
}

void initPWM_PF3(uint16_t freq)
{
    SYSCTL_RCGCPWM_R |= 2;        // Enable PWM1 module
    SYSCTL_RCGCGPIO_R |= 0x20;    // Enable clock for Port F
    while ((SYSCTL_PRGPIO_R & 0x20) == 0)
        ;  // Wait for Port F to be ready

    GPIO_PORTF_AMSEL_R &= ~0x08;  // 🔹 Disable analog on PF3
    GPIO_PORTF_AFSEL_R |= 0x08;   // 🔹 Enable alternate function on PF3
    GPIO_PORTF_PCTL_R &= ~0x0000F000;
    GPIO_PORTF_PCTL_R |= 0x00005000; // 🔹 Set PF3 as M1PWM7
    GPIO_PORTF_DEN_R |= 0x08;     // 🔹 Enable digital function on PF3

    SYSCTL_RCC_R &= ~(1 << 20); // 🔹 Use system clock for PWM (no pre-divide)

    PWM1_3_CTL_R = 0;             // 🔹 Disable PWM generator
    PWM1_3_GENB_R = 0x0000080C; // 🔹 Drive high at LOAD, clear at CMPB (for PF3)
    PWM1_3_LOAD_R = 16000000 / freq; // 🔹 Set PWM period (assuming 16 MHz clock)
    PWM1_3_CMPB_R = 1600 - 1;            // 🔹 Default 0% duty cycle
    PWM1_3_CTL_R |= 1;            // 🔹 Enable PWM generator
    PWM1_ENABLE_R |= 0x80;        // 🔹 Enable M1PWM7 (PF3)
}

void initPWM_PD1(uint16_t freq)
{
    SYSCTL_RCGCPWM_R |= 2;        // 🔹 Enable clock for PWM1 module
    SYSCTL_RCGCGPIO_R |= 0x08;    // 🔹 Enable clock for Port D
    while ((SYSCTL_PRGPIO_R & 0x08) == 0)
        ;  // 🔹 Wait for Port D to be ready

    GPIO_PORTD_AMSEL_R &= ~(1 << 1);  // 🔹 Disable analog on PD1
    GPIO_PORTD_AFSEL_R |= (1 << 1);   // 🔹 Enable alternate function on PD1
    GPIO_PORTD_PCTL_R &= ~0x000000F0; // 🔹 Clear PCTL bits for PD1
    GPIO_PORTD_PCTL_R |= 0x00000050;  // 🔹 Set PD1 as M1PWM1
    GPIO_PORTD_DEN_R |= (1 << 1);     // 🔹 Enable digital function on PD1

    SYSCTL_RCC_R &= ~(1 << 20); // 🔹 Use system clock for PWM (No pre-divide)

    PWM1_0_CTL_R = 0;            // 🔹 Disable Generator 0 before configuring
    PWM1_0_GENB_R = 0x0000080C;  // 🔹 Drive high at LOAD, clear at CMPB match
    PWM1_0_LOAD_R = 16000000 / freq; // 🔹 Set PWM period based on system clock
    PWM1_0_CMPB_R = 1599;           // 🔹 Default 0% duty cycle
    PWM1_0_CTL_R |= 1;           // 🔹 Enable PWM Generator 0
    PWM1_ENABLE_R |= 0x02;       // 🔹 Enable PWM1 (PD1)
}

void initPWM_PD0(uint16_t freq)
{
    SYSCTL_RCGCPWM_R |= 1;        // 🔹 Enable clock for PWM0 module
    SYSCTL_RCGCGPIO_R |= 0x08;    // 🔹 Enable clock for Port D
    while ((SYSCTL_PRGPIO_R & 0x08) == 0)
        ;  // 🔹 Wait for Port D to be ready

    GPIO_PORTD_AMSEL_R &= ~(1 << 0);  // 🔹 Disable analog on PD0
    GPIO_PORTD_AFSEL_R |= (1 << 0);   // 🔹 Enable alternate function on PD0
    GPIO_PORTD_PCTL_R &= ~0x0000000F; // 🔹 Clear PCTL bits for PD0
    GPIO_PORTD_PCTL_R |= 0x00000004;  // 🔹 Set PD0 as M0PWM6
    GPIO_PORTD_DEN_R |= (1 << 0);     // 🔹 Enable digital function on PD0

    SYSCTL_RCC_R &= ~(1 << 20); // 🔹 Use system clock for PWM (No pre-divider)

    PWM0_3_CTL_R = 0;            // 🔹 Disable Generator 3 before configuring
    PWM0_3_GENA_R = 0x0000080C;  // 🔹 Drive high at LOAD, clear at CMPA match
    PWM0_3_LOAD_R = 16000000 / freq; // 🔹 Set PWM period based on system clock
    PWM0_3_CMPA_R = 0;           // 🔹 Default 0% duty cycle
    PWM0_3_CTL_R |= 1;           // 🔹 Enable PWM Generator 3
    PWM0_ENABLE_R |= 0x40;       // 🔹 Enable PWM6 (PD0)

//    GPIO_PORTB_AFSEL_R &= ~(0xC0);  // Disable alternate function on PB6, PB7
//    GPIO_PORTB_PCTL_R &= ~0xFF000000; // Clear alternate function for PB6, PB7
//    GPIO_PORTB_DEN_R |= 0xC0;      // Enable digital function for PB6, PB7
}

//__attribute__((section(".init_array"))) void (*init_ptr)(void) = initSysTick;
