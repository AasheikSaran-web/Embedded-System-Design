#include "aasheik.h"

volatile bool timer_start = 1, timer_resume = 0;
volatile bool motorRun = 1, timerKeypadSet = 0;
volatile unsigned long timerMillis = 0, timerSetValue = 0;
const int segNum[10] = SEVEN_SEG_NUMS;
int LEDCOLOR = 0;
volatile uint16_t pwmDuty = 1599;
volatile uint32_t adcValue = 0;

void motorSpeedfromADC(void);
bool extract_number_RTC(char*);
void setdutyPWM_PD0(uint16_t duty);
void setdutyPWM_PD1(uint16_t duty);

///////////////////CAN-BEGIN/////////////////////////
volatile uint32_t g_ui32RXMsgCount = 0;
volatile uint32_t g_ui32TXMsgCount = 0;

volatile bool g_bRXFlag = 0;

volatile uint32_t g_ui32ErrFlag = 0;

tCANMsgObject g_sCAN0RxMessage;
tCANMsgObject g_sCAN0TxMessage;

#define CAN0RXID                0
#define RXOBJECT                1
#define CAN0TXID                2
#define TXOBJECT                2

uint8_t g_ui8TXMsgData;
uint8_t g_ui8RXMsgData;

#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line) { }
#endif

void CANIntHandler(void)
{
    uint32_t ui32Status;

    ui32Status = CANIntStatus(CAN0_BASE, CAN_INT_STS_CAUSE);

    if (ui32Status == CAN_INT_INTID_STATUS)
    {
        ui32Status = CANStatusGet(CAN0_BASE, CAN_STS_CONTROL);
        g_ui32ErrFlag |= ui32Status;
    }
    else if (ui32Status == RXOBJECT)
    {
        CANIntClear(CAN0_BASE, RXOBJECT);

        g_ui32RXMsgCount++;
        g_bRXFlag = true;
        g_ui32ErrFlag = 0;
    }
    else if (ui32Status == TXOBJECT)
    {
        CANIntClear(CAN0_BASE, TXOBJECT);

        g_ui32TXMsgCount++;
        g_ui32ErrFlag = 0;
    }
    else
    {
        // Spurious interrupt handling can go here.
    }
}

void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    UARTStdioConfig(0, 115200, 16000000);
}

void InitCAN0(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);

    GPIOPinConfigure(GPIO_PE4_CAN0RX);
    GPIOPinConfigure(GPIO_PE5_CAN0TX);
    GPIOPinTypeCAN(GPIO_PORTE_BASE, GPIO_PIN_4 | GPIO_PIN_5);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_CAN0);
    CANInit(CAN0_BASE);
    CANBitRateSet(CAN0_BASE, SysCtlClockGet(), 500000);
    CANIntEnable(CAN0_BASE, CAN_INT_MASTER | CAN_INT_ERROR | CAN_INT_STATUS);
    IntEnable(INT_CAN0);

    // Enable test bit on CANCTL
    //CAN0_CTL_R |= CAN_CTL_TEST;
    // Set loopback mode
    //CAN0_TST_R |= CAN_TST_LBACK;

    CANEnable(CAN0_BASE);

    g_sCAN0RxMessage.ui32MsgID = CAN0RXID;
    g_sCAN0RxMessage.ui32MsgIDMask = 0;
    g_sCAN0RxMessage.ui32Flags = MSG_OBJ_RX_INT_ENABLE | MSG_OBJ_USE_ID_FILTER;
    g_sCAN0RxMessage.ui32MsgLen = sizeof(g_ui8RXMsgData);

    CANMessageSet(CAN0_BASE, RXOBJECT, &g_sCAN0RxMessage, MSG_OBJ_TYPE_RX);

    g_ui8TXMsgData = 0;
    g_sCAN0TxMessage.ui32MsgID = CAN0TXID;
    g_sCAN0TxMessage.ui32MsgIDMask = 0;
    g_sCAN0TxMessage.ui32Flags = MSG_OBJ_TX_INT_ENABLE;
    g_sCAN0TxMessage.ui32MsgLen = sizeof(g_ui8TXMsgData);
    g_sCAN0TxMessage.pui8MsgData = (uint8_t*) &g_ui8TXMsgData;
}

void delayMs(int ms)
{
    int i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 3180; j++)
        {
        }  // 1 ms delay approx at 16 MHz
}

void CANErrorHandler(void)
{
//    if (g_ui32ErrFlag & CAN_STATUS_BUS_OFF)
//    {
//        // Handle Error Condition here
//        UARTprintf("    ERROR: CAN_STATUS_BUS_OFF \n");
//
//        // Clear CAN_STATUS_BUS_OFF Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_BUS_OFF);
//    }
//
//    // CAN controller error level has reached warning level.
//    if (g_ui32ErrFlag & CAN_STATUS_EWARN)
//    {
//        // Handle Error Condition here
//        // UARTprintf("    ERROR: CAN_STATUS_EWARN \n");
//
//        // Clear CAN_STATUS_EWARN Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_EWARN);
//    }
//
//    // CAN controller error level has reached error passive level.
//    if (g_ui32ErrFlag & CAN_STATUS_EPASS)
//    {
//        // Handle Error Condition here
//        // UARTprintf("    ERROR: CAN_STATUS_EPASS \n");
//
//        // Clear CAN_STATUS_EPASS Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_EPASS);
//    }
//
//    // A message was received successfully since the last read of this status.
//    if (g_ui32ErrFlag & CAN_STATUS_RXOK)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_RXOK Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_RXOK);
//    }
//
//    // A message was transmitted successfully since the last read of this
//    // status.
//    if (g_ui32ErrFlag & CAN_STATUS_TXOK)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_TXOK Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_TXOK);
//    }
//
//    // This is the mask for the last error code field.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_MSK)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_MSK Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_MSK);
//    }
//
//    // A bit stuffing error has occurred.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_STUFF)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_STUFF Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_STUFF);
//    }
//
//    // A formatting error has occurred.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_FORM)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_FORM Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_FORM);
//    }
//
//    // An acknowledge error has occurred.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_ACK)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_ACK Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_ACK);
//    }
//
//    // The bus remained a bit level of 1 for longer than is allowed.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_BIT1)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_BIT1 Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_BIT1);
//    }
//
//    // The bus remained a bit level of 0 for longer than is allowed.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_BIT0)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_BIT0 Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_BIT0);
//    }
//
//    // A CRC error has occurred.
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_CRC)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_CRC Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_CRC);
//    }
//
//    // This is the mask for the CAN Last Error Code (LEC).
//    if (g_ui32ErrFlag & CAN_STATUS_LEC_MASK)
//    {
//        // Handle Error Condition here
//
//        // Clear CAN_STATUS_LEC_MASK Flag
//        g_ui32ErrFlag &= ~(CAN_STATUS_LEC_MASK);
//    }
//
//    // If there are any bits still set in g_ui32ErrFlag then something unhandled
//    // has happened. Print the value of g_ui32ErrFlag.
//    if (g_ui32ErrFlag != 0)
//    {
//        UARTprintf("    Unhandled ERROR: %x \n", g_ui32ErrFlag);
//    }
}

void cancan(void)
{
    static char strIn[30] = "\0";

    if (g_bRXFlag)
    {
        g_sCAN0RxMessage.pui8MsgData = (uint8_t*) &g_ui8RXMsgData;

        CANMessageGet(CAN0_BASE, RXOBJECT, &g_sCAN0RxMessage, 0);

        g_bRXFlag = 0;

//        if (g_sCAN0RxMessage.ui32Flags & MSG_OBJ_DATA_LOST)
//        {
//            UARTprintf("\nCAN message loss detected\n");
//        }

        UARTprintf("%c", g_ui8RXMsgData);

        ////////////////////////////////////////////

        addChar(g_ui8RXMsgData, strIn);
        processString(strIn);
        ////////////////////////////////////////
    }
    else
    {
        if (g_ui32ErrFlag != 0)
        {
            CANErrorHandler();
        }

        while (UARTCharsAvail(UART0_BASE))
        {
            g_ui8TXMsgData = UARTCharGetNonBlocking(UART0_BASE);

            CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                          MSG_OBJ_TYPE_TX);
            UARTprintf("Msgs sent: %d. Msgs rcvd: %d\n", g_ui32TXMsgCount,
                       g_ui32RXMsgCount);

            ////////////////////////////////////////////

            //char val = UARTCharGet(UART0_BASE);
            UARTprintf("%c", g_ui8TXMsgData);
            addChar(g_ui8TXMsgData, strIn);
            processString(strIn);
            ////////////////////////////////////////

        }
    }
}

////////////////////CAN-END//////////////////////////////////////

void main()
{

    initPORTC(); //input-from-keypad
    initPORTE(); //output-to-keypad

    initPORTA(); //segment-select
    initPORTB(); //segment-character
    initPORTF(); //led
    initSW();
    initSysTick();
    initTimer0();
//initUART0Interrupt(115200);
    ConfigureUART();

    initINTPRI();

    initADC0();          // Initialize ADC0 on PE3
    initPWM_PF2(10000);
    initPWM_PF3(10000);
    initPWM_PD1(10000);
    initPWM_PD0(10000);

/////////////////CN///////////////
    FPULazyStackingEnable();

    //SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_XTAL_16MHZ |
    //SYSCTL_OSC_MAIN);

    ConfigureUART();
    InitCAN0();

    UARTprintf("Type something to see it show up on the other terminal: \n\n");
////////////////////////////////////////////

    while (1)
    {
        keypadColRead();
        motorSpeedfromADC();

    }
}

void addChar(char c, char *strIn)
{
    int len = strlen(strIn);

    if (c == '\b')
    {
        if (len > 0)
        {
            strIn[len - 1] = '\0';
        }
    }
    else
    {

        if (len >= 30)
        {
            char *err = "\nOVERFLOW........CLEARING BUFFER\n";
            while (*err)
                UARTCharPut(UART0_BASE, *err++);
            strIn[0] = '\0';
        }
        strIn[len] = c;
        strIn[len + 1] = '\0';

    }
}

void processString(char *strIn)
{
    char cleanedStrAlpha[30], cleanedStrAlNum[30];
    int j = 0, k = 0;
    bool LedStateChange = 0, TimerStateChange = 0, BlinkStateChange = 0,
            TimerValSet = 0, rtcValSet;

    for (int i = 0; strIn[i] != '\0'; i++)
    {

        if (!isspace((unsigned char) strIn[i]))
        {
            if (isalpha((unsigned char) strIn[i]))
                cleanedStrAlpha[j++] = toupper(strIn[i]);

            if (isalnum((unsigned char) strIn[i]))
                cleanedStrAlNum[k++] = toupper(strIn[i]);
        }
    }
    cleanedStrAlpha[j] = '\0';
    cleanedStrAlNum[k] = '\0';

    LedStateChange = ledColor(cleanedStrAlpha);
    TimerStateChange = timerCMD(cleanedStrAlpha);
    BlinkStateChange = extract_number_pwmduty(cleanedStrAlNum);
    TimerValSet = extract_number_timer(cleanedStrAlNum);
    rtcValSet = extract_number_RTC(cleanedStrAlNum);

    if (LedStateChange)
    {
        TIMER0_CTL_R &= ~(1 << 0);
    }

    if (LedStateChange || TimerStateChange || BlinkStateChange || TimerValSet
            || rtcValSet)
    {
        strIn[0] = '\0';
    }

}

bool extract_number_pwmduty(char *cleanedStrAlNum)
{
    bool cmdFlag = 0;

    char *foundLEDBLINK = strstr(cleanedStrAlNum, "PWMDUTY");
    if (foundLEDBLINK)
        foundLEDBLINK += 7;
    else
        return 0;

    while (!isdigit((unsigned char) *foundLEDBLINK))
    {
        foundLEDBLINK++;
    }

// Extract number
    int blinkrate = 1599;
    if (isdigit((unsigned char) *foundLEDBLINK)
            && sscanf(foundLEDBLINK, "%4d", &blinkrate) == 1)
    {

    }

    int numDigits = 0;

    while (isdigit((unsigned char) *foundLEDBLINK) && numDigits < 4)
    {
        foundLEDBLINK++;
        numDigits++;
    }

    if (numDigits == 4)
    {
        pwmDuty = blinkrate;
        cmdFlag = 1;
    }

    return cmdFlag;
}

bool extract_number_timer(char *cleanedStrAlNum)
{
    bool cmdFlag = 0;

    char *foundTIMERSET = strstr(cleanedStrAlNum, "TIMERSET");

    if (foundTIMERSET)
        foundTIMERSET += 8;
    else
        return 0;

    while (*foundTIMERSET != '\0' && !isdigit((unsigned char) *foundTIMERSET))
    {
        foundTIMERSET++;
    }

// Extract number
    int timerValMin = 0;
    if (isdigit((unsigned char) *foundTIMERSET)
            && sscanf(foundTIMERSET, "%4d", &timerValMin) == 1)
    {
        timerMillis = timerValMin * 1000;
        timer_start = 1;
    }

    int numDigits = 0;

    while (isdigit((unsigned char) *foundTIMERSET) && numDigits < 3)
    {
        foundTIMERSET++;
        numDigits++;
    }

    if (numDigits == 4)
    {
        cmdFlag = 1;
    }

    return cmdFlag;
}

bool ledColor(char *cleanedStrAlpha)
{
    bool cmdFlag = 0;

    char *foundRED = strstr(cleanedStrAlpha, "LEDRED");
    char *foundBLUE = strstr(cleanedStrAlpha, "LEDBLUE");
    char *foundGREEN = strstr(cleanedStrAlpha, "LEDGREEN");
    char *foundCYAN = strstr(cleanedStrAlpha, "LEDCYAN");
    char *foundMAGENTA = strstr(cleanedStrAlpha, "LEDMAGENTA");
    char *foundYELLOW = strstr(cleanedStrAlpha, "LEDYELLOW");
    char *foundWHITE = strstr(cleanedStrAlpha, "LEDWHITE");

    if (foundRED)
    {
        GPIO_PORTF_DATA_R = LED_RED;
        LEDCOLOR = LED_RED;
        cmdFlag = 1;
    }
    else if (foundBLUE)
    {
        GPIO_PORTF_DATA_R = LED_BLUE;
        LEDCOLOR = LED_BLUE;
        cmdFlag = 1;
    }
    else if (foundGREEN)
    {
        GPIO_PORTF_DATA_R = LED_GREEN;
        LEDCOLOR = LED_GREEN;
        cmdFlag = 1;
    }
    else if (foundCYAN)
    {
        GPIO_PORTF_DATA_R = LED_CYAN;
        LEDCOLOR = LED_CYAN;
        cmdFlag = 1;
    }
    else if (foundMAGENTA)
    {
        GPIO_PORTF_DATA_R = LED_MAGENTA;
        LEDCOLOR = LED_MAGENTA;
        cmdFlag = 1;
    }
    else if (foundYELLOW)
    {
        GPIO_PORTF_DATA_R = LED_YELLOW;
        LEDCOLOR = LED_YELLOW;
        cmdFlag = 1;
    }
    else if (foundWHITE)
    {
        GPIO_PORTF_DATA_R = LED_WHITE;
        LEDCOLOR = LED_WHITE;
        cmdFlag = 1;
    }

    return cmdFlag;

}

bool timerCMD(char *cleanedStr)
{
    bool cmdFlag = 0;

    char *foundSTOP = strstr(cleanedStr, "SWTSTOP");
    char *foundSTART = strstr(cleanedStr, "SWTSTART");
    char *foundPAUSE = strstr(cleanedStr, "SWTPAUSE");
    char *foundRESUME = strstr(cleanedStr, "SWTRESUME");

    if (foundSTOP)
    {
        timer_start = 0;
        cmdFlag = 1;
    }
    else if (foundSTART)
    {
        timer_start = 1;
        cmdFlag = 1;
    }
    else if (foundPAUSE)
    {
        timer_resume = 0;
        cmdFlag = 1;
    }
    else if (foundRESUME)
    {
        timer_resume = 1;
        cmdFlag = 1;
    }

    return cmdFlag;

}

void TIMER0A_Handler(void)
{
    TIMER0_ICR_R = 0x01;
    GPIO_PORTF_DATA_R ^= LEDCOLOR;
}

void SW_Handler(void)
{
    GPIO_PORTF_ICR_R |= ((1 << 4) | (1 << 0));      // acknowledge flag4

    volatile unsigned long currentMillis = millis();
    static volatile unsigned long previousMillis = 0;

    if ((currentMillis - previousMillis) >= 50)
    {
        if (GPIO_PORTF_RIS_R & (1 << 4))
        {
            timer_start ^= 1;

            if (timer_start)
            {
                char *canmsg = "swtstart";
                while (*canmsg)
                {
                    g_ui8TXMsgData = *canmsg++;

                    CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                                  MSG_OBJ_TYPE_TX);

                    delayMs(1);
                }
            }
            else
            {
                char *canmsg = "swtstop";
                while (*canmsg)
                {
                    g_ui8TXMsgData = *canmsg++;

                    CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                                  MSG_OBJ_TYPE_TX);

                    delayMs(1);

                }
            }

        }
        else if (GPIO_PORTF_RIS_R & (1 << 0))
        {
            char tempcanmsg[20];
            sprintf(tempcanmsg, "timerset%d", (timerMillis / 1000));
            char *canmsg = tempcanmsg;
            while (*canmsg)
            {
                g_ui8TXMsgData = *canmsg++;

                CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                              MSG_OBJ_TYPE_TX);

                delayMs(1);

            }

            timer_resume ^= 1;

            if (timer_resume)
            {
                char *canmsg = "swtresume";
                while (*canmsg)
                {
                    g_ui8TXMsgData = *canmsg++;

                    CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                                  MSG_OBJ_TYPE_TX);

                    delayMs(1);
                }
            }
            else
            {
                char *canmsg = "swtpause";
                while (*canmsg)
                {
                    g_ui8TXMsgData = *canmsg++;

                    CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                                  MSG_OBJ_TYPE_TX);

                    delayMs(1);

                }
            }

        }
    }

    previousMillis = currentMillis;

}

void segment7(void)
{
    const int segNum[10] = SEVEN_SEG_NUMS;

    static volatile unsigned long currentMillis = 0;
    static volatile unsigned long previousMillis = 0;
    currentMillis = millis();

    if (timerMillis == 0)
    {

        GPIO_PORTF_DATA_R = LED_RED;
        setdutyPWM_PF3(1599);
        setdutyPWM_PF2(1599);

        timer_start = 1;
        timer_resume = 0;
        motorRun = 0;
        timerKeypadSet = 1;
    }

    if (timerMillis > 0 && motorRun == 0)
    {
        GPIO_PORTF_DATA_R &= ~LED_RED;
        setdutyPWM_PF3(0);
        setdutyPWM_PD1(1599);
    }

    if (timer_start == 1)
    {
        if (timer_resume == 1)
        {
            GPIO_PORTF_DATA_R &= ~LED_RED;
            timerKeypadSet = 0;
            motorRun = 1;
            timerMillis--;
        }
    }
    else
    {
        timerMillis = 0;
    }

    static int seg7[4] = { 0, 0, 0, 0 };

    static int prepwmDuty = 0;
    static bool ADCflag = 0;

//    pwmDuty = adcValue * 1600 / 4096;

    if (abs(pwmDuty - adcValue * 1600 / 4096) < 200)
    {
        pwmDuty = adcValue * 1600 / 4096;

    }

    if (abs(pwmDuty - prepwmDuty) > 50)
    {
        ADCflag = 1;
        prepwmDuty = pwmDuty;

        char tempcanmsg[20] = "pwmduty";
        tempcanmsg[7] = '0' + (pwmDuty / 1000);
        tempcanmsg[8] = '0' + ((pwmDuty / 100) % 10);
        tempcanmsg[9] = '0' + ((pwmDuty / 10) % 10);
        tempcanmsg[10] = '0' + (pwmDuty % 10);
        tempcanmsg[11] = '\0';

        char *canmsg = tempcanmsg;
        while (*canmsg)
        {
            g_ui8TXMsgData = *canmsg++;

            CANMessageSet(CAN0_BASE, TXOBJECT, &g_sCAN0TxMessage,
                          MSG_OBJ_TYPE_TX);

            delayMs(1);

        }
    }

    if ((currentMillis - previousMillis) >= 1)
    {
        if (ADCflag)
        {
            static int tempDisp = 0;
            tempDisp++;

            if (tempDisp > 3000)
            {
                tempDisp = 0;
                ADCflag = 0;
            }

            seg7[3] = segNum[((pwmDuty * 4095 / 1600) / 1000) % 10];
            seg7[2] = segNum[((pwmDuty * 4095 / 1600) / 100) % 10];
            seg7[1] = segNum[((pwmDuty * 4095 / 1600) / 10) % 10];
            seg7[0] = segNum[(pwmDuty * 4095 / 1600) % 10];
        }
        else
        {
            //MM:SS
//            seg7[3] = segNum[(timerMillis / 600000) % 6];
//            seg7[2] = segNum[(timerMillis / 60000) % 10] | 0b10000000;
//            seg7[1] = segNum[(timerMillis / 10000) % 6];
//            seg7[0] = segNum[(timerMillis / 1000) % 10];

            //M:SS:MS

            seg7[3] = segNum[(timerMillis / 60000) % 10];
            seg7[2] = segNum[(timerMillis / 10000) % 6];
            seg7[1] = segNum[(timerMillis / 1000) % 10];
            seg7[0] = segNum[(timerMillis / 100) % 10];
        }

        static int i = 0;
        GPIO_PORTB_DATA_R = seg7[i];
        GPIO_PORTA_DATA_R = (0b00010000 << i);

        i++;
        if (i > 3)
            i = 0;

        previousMillis = currentMillis;
    }
}

void UART0_Handler_Interrupt(void)
{
    int status = UARTIntStatus(UART0_BASE, true);
    UARTIntClear(UART0_BASE, status);

    static char strIn[30] = "\0";

    if (status & UART_INT_RX)  // If data is received
    {
        char val = UARTCharGet(UART0_BASE);
        UARTCharPut(UART0_BASE, val);
        addChar(val, strIn);
        processString(strIn);
    }

}

void keypadColRead(void)
{
    volatile unsigned long currentMillis = millis();
    static volatile unsigned long previousMillis = 0;

    if (timerKeypadSet)
    {
        if (!COL1)
        {

            if ((currentMillis - previousMillis) >= 50)
            {

                if ((GPIO_PORTE_DATA_R & 0b1111) == 0b110)
                {
                    timerMillis = timerMillis * 10 + 1000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b101)
                {
                    timerMillis = timerMillis * 10 + 4000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b011)
                {
                    timerMillis = timerMillis * 10 + 7000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b111)
                {
                }

            }
            previousMillis = currentMillis;
        }

        else if (!COL2)
        {

            if ((currentMillis - previousMillis) >= 50)
            {
                if ((GPIO_PORTE_DATA_R & 0b1111) == 0b110)
                {
                    timerMillis = timerMillis * 10 + 2000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b101)
                {
                    timerMillis = timerMillis * 10 + 5000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b011)
                {
                    timerMillis = timerMillis * 10 + 8000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b111)
                {
                }

            }

            previousMillis = currentMillis;

        }
        else if (!COL3)
        {

            if ((currentMillis - previousMillis) >= 50)
            {
                if ((GPIO_PORTE_DATA_R & 0b1111) == 0b110)
                {
                    timerMillis = timerMillis * 10 + 3000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b101)
                {
                    timerMillis = timerMillis * 10 + 6000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b011)
                {
                    timerMillis = timerMillis * 10 + 9000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b111)
                {

                }

            }

            previousMillis = currentMillis;

        }
        else if (!COL4)
        {

            if ((currentMillis - previousMillis) >= 50)
            {
                if ((GPIO_PORTE_DATA_R & 0b1111) == 0b110)
                {

                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b101)
                {
                    timerMillis = timerMillis * 10 + 0000;
                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b011)
                {

                }
                else if ((GPIO_PORTE_DATA_R & 0b1111) == 0b111)
                {

                }

            }

            previousMillis = currentMillis;

        }
    }

}

void keypadRowSelect(void)
{
    volatile unsigned long currentMillis = millis();
    static volatile unsigned long previousMillis = 0;

    if ((currentMillis - previousMillis) >= 10)
    {
        static int i = 0;

        GPIO_PORTE_DATA_R = 0b1111 & ~(1 << i);

        i++;
        if (i > 2)
            i = 0;

        previousMillis = currentMillis;

    }

}

void motorSpeedfromADC(void)
{
/////////Read from ADC/////////////////
    ADC0_PSSI_R = 0x08;           // Start conversion
    while ((ADC0_RIS_R & 0x08) == 0)
        ;  // Wait for conversion
    adcValue = ADC0_SSFIFO3_R;  // Read result
    ADC0_ISC_R = 0x08;           // Clear flag

//////////Set PWM//////////////////////

    if (motorRun)
    {

        if (timer_resume == 0)
        {
            setdutyPWM_PF2(pwmDuty);
            setdutyPWM_PF3(1599);

            setdutyPWM_PD1(1599);
        }
        else
        {
            setdutyPWM_PF2(1599);
            setdutyPWM_PF3(pwmDuty);

            setdutyPWM_PD1(pwmDuty);
        }

//        if (pwmDuty > 800)
//        {
//            setdutyPWM_PD0((pwmDuty - 800) * 2);
//            setdutyPWM_PD1(0);
//        }
//        else
//        {
//            setdutyPWM_PD0(0);
//            setdutyPWM_PD1((800 - pwmDuty) * 2);
//        }
    }
    else
    {
        setdutyPWM_PF2(1599);
        setdutyPWM_PD1(1599);
    }

}

// Set PWM duty cycle
void setdutyPWM_PF2(uint32_t duty)
{
    if (duty >= 1600)
        duty = 1600 - 1;  // Prevent out-of-range values
    PWM1_3_CMPA_R = duty;             // Update duty cycle
}

void setdutyPWM_PF3(uint32_t duty)
{
    if (duty >= 1600)
        duty = 1600 - 1;  // Prevent out-of-range values
    PWM1_3_CMPB_R = duty;             // Update duty cycle
}

void setdutyPWM_PD1(uint16_t duty)
{
    if (duty >= 1600)
        duty = 1600 - 1;  // Prevent out-of-range values
    PWM1_0_CMPB_R = duty;             // Update duty cycle
}

void setdutyPWM_PD0(uint16_t duty)
{
    if (duty >= 1600)
        duty = 1600 - 1;  // Prevent out-of-range values
    PWM0_3_CMPA_R = duty;             // Update duty cycle
}

bool extract_number_RTC(char *cleanedStrAlNum)
{
    bool cmdFlag = 0;

    char *foundLEDBLINK = strstr(cleanedStrAlNum, "SETRTC");
    if (foundLEDBLINK)
        foundLEDBLINK += 6;
    else
        return 0;

    while (!isdigit((unsigned char) *foundLEDBLINK))
    {
        foundLEDBLINK++;
    }

// Extract number
    unsigned long long rtcdata = 0;
    if (isdigit((unsigned char) *foundLEDBLINK)
            && sscanf(foundLEDBLINK, "%12llu", &rtcdata) == 1)
    {

    }

    int numDigits = 0;

    while (isdigit((unsigned char) *foundLEDBLINK) && numDigits < 12)
    {
        foundLEDBLINK++;
        numDigits++;
    }

    if (numDigits == 12)
    {
        uint8_t hours, minutes, seconds;
        uint8_t day, month, year;

        day = (rtcdata / 10000000000);
        month = (rtcdata / 100000000) % 100;
        year = (rtcdata / 1000000) % 100;
        hours = (rtcdata / 10000) % 100;
        minutes = (rtcdata / 100) % 100;
        seconds = rtcdata % 100;

        UARTprintf("\n\nDate: %2d/%2d/%2d\n", day, month, year);
        UARTprintf("Time: %2d/%2d/%2d\n", hours, minutes, seconds);

        cmdFlag = 1;
    }

    return cmdFlag;
}

